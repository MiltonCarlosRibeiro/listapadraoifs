package br.com.pakmatic.listapadraoifs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListapadraoifsApplicationTests {

	@Test
	void contextLoads() {
	}

}
